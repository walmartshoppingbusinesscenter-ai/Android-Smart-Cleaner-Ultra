# Android Smart Cleaner Pro 2.0

Privacy-first Android storage review app built with Kotlin and Jetpack Compose.

## Features
- Storage capacity overview.
- Light/dark themes and Persian/English language selection.
- Local scan of shared images and videos larger than 20 MB using MediaStore.
- No automatic deletion; Android system confirmation is required for deletion on Android 11+.

## Android storage limitations
Scoped storage prevents ordinary apps from freely inspecting other apps' private directories and system caches. This app does not claim to remove all uninstall leftovers, system temporary files, or empty folders. It does not request MANAGE_EXTERNAL_STORAGE.

## Privacy
Media is queried locally. No files are uploaded. Read access is limited to shared images and videos. Deletion requires explicit Android confirmation.

## Build
Open this directory in Android Studio or use the repository's GitHub Actions workflow to build the debug APK.

## License
MIT.
