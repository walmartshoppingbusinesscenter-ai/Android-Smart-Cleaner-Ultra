package com.smartcleanerpro.app

import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.os.LocaleListCompat
import java.util.Locale

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("smart_cleaner_prefs", MODE_PRIVATE)
        val dark = prefs.getBoolean("dark_theme", false)
        val language = prefs.getString("language", "system") ?: "system"
        AppCompatDelegate.setDefaultNightMode(
            if (dark) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
        )
        if (language != "system") {
            AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(language))
        }
        setContent {
            var isDark by remember { mutableStateOf(dark) }
            var selectedLanguage by remember { mutableStateOf(language) }
            SmartCleanerTheme(darkTheme = isDark) {
                CleanerDashboard(
                    darkTheme = isDark,
                    onDarkThemeChange = {
                        isDark = it
                        prefs.edit().putBoolean("dark_theme", it).apply()
                        AppCompatDelegate.setDefaultNightMode(
                            if (it) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
                        )
                    },
                    selectedLanguage = selectedLanguage,
                    onLanguageChange = {
                        selectedLanguage = it
                        prefs.edit().putString("language", it).apply()
                        AppCompatDelegate.setApplicationLocales(
                            if (it == "system") LocaleListCompat.getEmptyLocaleList()
                            else LocaleListCompat.forLanguageTags(it)
                        )
                    }
                )
            }
        }
    }
}

@Composable
private fun SmartCleanerTheme(darkTheme: Boolean, content: @Composable () -> Unit) {
    val colorScheme = if (darkTheme) darkColorScheme() else lightColorScheme()
    MaterialTheme(colorScheme = colorScheme, content = content)
}

private data class StorageInfo(val total: Long, val free: Long) {
    val used: Long get() = (total - free).coerceAtLeast(0)
    val fraction: Float get() = if (total > 0) used.toFloat() / total.toFloat() else 0f
}

private fun readStorage(): StorageInfo {
    return try {
        val stat = StatFs(Environment.getDataDirectory().path)
        StorageInfo(stat.totalBytes, stat.availableBytes)
    } catch (_: Exception) {
        StorageInfo(0L, 0L)
    }
}

private fun formatGb(bytes: Long): String =
    String.format(Locale.getDefault(), "%.1f", bytes / (1024.0 * 1024.0 * 1024.0))

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CleanerDashboard(
    darkTheme: Boolean,
    onDarkThemeChange: (Boolean) -> Unit,
    selectedLanguage: String,
    onLanguageChange: (String) -> Unit
) {
    val storage = remember { readStorage() }
    val usedText = formatGb(storage.used)
    val freeText = formatGb(storage.free)
    val totalText = formatGb(storage.total)

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = androidx.compose.ui.res.stringResource(R.string.app_title),
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = androidx.compose.ui.res.stringResource(R.string.subtitle),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    Icon(Icons.Default.Shield, contentDescription = "Privacy")
                    Spacer(Modifier.width(16.dp))
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            StorageCard(storage, usedText, freeText, totalText)
            Text(
                androidx.compose.ui.res.stringResource(R.string.quick_actions),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ActionCard(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Default.FolderOpen,
                    title = androidx.compose.ui.res.stringResource(R.string.large_files)
                )
                ActionCard(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Default.FileCopy,
                    title = androidx.compose.ui.res.stringResource(R.string.duplicates)
                )
            }
            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Search, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            androidx.compose.ui.res.stringResource(R.string.scan),
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Text(
                        androidx.compose.ui.res.stringResource(R.string.scan_note),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            SettingsCard(
                darkTheme = darkTheme,
                onDarkThemeChange = onDarkThemeChange,
                selectedLanguage = selectedLanguage,
                onLanguageChange = onLanguageChange
            )
            Text(
                androidx.compose.ui.res.stringResource(R.string.storage_note),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun StorageCard(storage: StorageInfo, used: String, free: String, total: String) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text(
                androidx.compose.ui.res.stringResource(R.string.storage_title),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(contentAlignment = Alignment.Center, modifier = Modifier.size(132.dp)) {
                    CircularProgressIndicator(
                        progress = { storage.fraction.coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxSize(),
                        strokeWidth = 12.dp,
                        strokeCap = StrokeCap.Round
                    )
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("$used", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        Text(androidx.compose.ui.res.stringResource(R.string.gb), style = MaterialTheme.typography.labelMedium)
                    }
                }
                Spacer(Modifier.width(20.dp))
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    StorageLegend(androidx.compose.ui.res.stringResource(R.string.used), used)
                    StorageLegend(androidx.compose.ui.res.stringResource(R.string.free), free)
                    StorageLegend(androidx.compose.ui.res.stringResource(R.string.total), total)
                }
            }
        }
    }
}

@Composable
private fun StorageLegend(label: String, value: String) {
    Column {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text("$value GB", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun ActionCard(modifier: Modifier, icon: androidx.compose.ui.graphics.vector.ImageVector, title: String) {
    Card(modifier = modifier) {
        Column(
            modifier = Modifier.padding(16.dp).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Text(title, fontWeight = FontWeight.SemiBold)
            Text("Coming soon", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun SettingsCard(
    darkTheme: Boolean,
    onDarkThemeChange: (Boolean) -> Unit,
    selectedLanguage: String,
    onLanguageChange: (String) -> Unit
) {
    Card {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(
                androidx.compose.ui.res.stringResource(R.string.settings),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.DarkMode, contentDescription = null)
                Spacer(Modifier.width(12.dp))
                Text(androidx.compose.ui.res.stringResource(R.string.dark_mode), modifier = Modifier.weight(1f))
                Switch(checked = darkTheme, onCheckedChange = onDarkThemeChange)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Language, contentDescription = null)
                Spacer(Modifier.width(12.dp))
                Text(androidx.compose.ui.res.stringResource(R.string.language), modifier = Modifier.weight(1f))
                LanguageChoice(selectedLanguage, onLanguageChange)
            }
        }
    }
}

@Composable
private fun LanguageChoice(selectedLanguage: String, onLanguageChange: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val current = when (selectedLanguage) {
        "fa" -> "فارسی"
        "en" -> "English"
        else -> "System"
    }
    Box {
        TextButton(onClick = { expanded = true }) { Text(current) }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            DropdownMenuItem(text = { Text("System") }, onClick = { onLanguageChange("system"); expanded = false })
            DropdownMenuItem(text = { Text("English") }, onClick = { onLanguageChange("en"); expanded = false })
            DropdownMenuItem(text = { Text("فارسی") }, onClick = { onLanguageChange("fa"); expanded = false })
        }
    }
}
